package com.example.project05mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project05MongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
